<?php

    const BASE_URL = "http://localhost/agenda/";
    date_default_timezone_set("America/Asuncion");

    //Datos de conexion a la base de datos 
    const DB_HOST = "localhost";
    const DB_USER = "root";
    const DB_PASSWORD = "";
    const DB_NAME = "agenda_medica";
    const DB_CHARSET = "charset=utf8";

    const SPD = ".";
    const SPM = ",";
    const MONEY = "Gs. ";