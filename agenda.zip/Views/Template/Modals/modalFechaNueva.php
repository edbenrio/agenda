<div class="modal" id="modalFormFechaNueva" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Fecha</h5>
            </div>
            <div class="modal-body">
                <form id="formFechaNueva" name="formFechaNueva">
                   <p>¿Desea habilitar esta fecha?</p>
                   <input class="hiddenIdFechaNueva" type="hidden" id="hiddenIdFechaNueva" name="hiddenIdFechaNueva"  >
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="cerrarModalFechaNueva()">Cancelar</button>
                        <button type="submit" class="btn btn-success">Habilitar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>