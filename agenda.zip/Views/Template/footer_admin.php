<!-- Essential javascripts for application to work-->
<script src= "<?= media();?>/js/jquery-3.3.1.min.js"></script>
    <script src= "<?= media();?>/js/jquery-ui.min.js"></script>
    <script src= "<?= media();?>/js/popper.min.js"></script>
    <script src= "<?= media();?>/js/bootstrap.min.js"></script>
    <script src= "<?= media();?>/js/main.js"></script>
    <script src= "<?= media();?>/js/functions.js"></script>

  </body>
</html>